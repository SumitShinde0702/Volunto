//
//  volunto_1App.swift
//  volunto_1
//
//  Created by Ong Si Hui on 9/2/24.
//

import SwiftUI

@main
struct volunto_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
