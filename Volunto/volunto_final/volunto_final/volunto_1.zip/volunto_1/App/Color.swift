//
//  Color.swift
//  volunto
//
//  Created by Ong Si Hui on 7/2/24.
//

import SwiftUI

extension Color {
    static let appColor: Color = Color(UIColor.systemPurple)
}
